package com.example.eventmanegmentsystem.EventAPI;

public interface EventViewMessage {

    void onUpdateFailure(String message);
    void onUpdateSuccess(String message);

}
