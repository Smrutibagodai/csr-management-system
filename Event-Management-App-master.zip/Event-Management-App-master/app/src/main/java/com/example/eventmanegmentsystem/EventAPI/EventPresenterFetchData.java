package com.example.eventmanegmentsystem.EventAPI;

import android.app.Activity;

public interface EventPresenterFetchData {

    void onSuccessUpdate(Activity activity);
}
