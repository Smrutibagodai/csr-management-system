package com.example.eventmanegmentsystem.EventAPI;

public interface EventViewFetchData {

    void onUpdateSuccess(EventModule message);
    void onUpdateFailure(String message);

}
