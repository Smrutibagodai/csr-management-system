package com.example.eventmanegmentsystem.CustomerAPI;

import android.app.Activity;

public interface CustomerPresenterFetchData {

    void onSuccessUpdate(Activity activity);
}
